package com.example.nightlibrary.core.security

import com.example.nightlibrary.security.ChunkIndex
import org.json.JSONObject
import java.io.File

class ChunkIndexReader {

    fun read(folder: File): ChunkIndex {
        val f = File(folder, "index.json")
        val j = JSONObject(f.readText())

        return ChunkIndex(
            j.getInt("chunkCount"),
            j.getInt("chunkSize"),
            j.getLong("totalFileSize")
        )
    }
    fun readIndex(folder:File) : ChunkIndex = read(folder)
}


