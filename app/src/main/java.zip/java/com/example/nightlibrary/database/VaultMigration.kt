package com.example.nightlibrary.database

import android.util.Log
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * All Room migrations for VaultDatabase.
 * Each migration safely adds columns with try-catch to prevent
 * crashes on re-install or migration re-run.
 */
object VaultMigrations {

    private const val TAG = "VaultMigrations"

    /**
     * Migration 7→8: Add currentSpeed column.
     * (Already existed in your codebase)
     */
    val MIGRATION_ADD_SPEED = object : Migration(7, 8) {
        override fun migrate(db: SupportSQLiteDatabase) {
            safeAddColumn(db, "media", "currentSpeed", "REAL NOT NULL DEFAULT 0.0")
        }
    }

    /**
     * Migration 8→9: (Your existing migration if any — placeholder)
     * If version 9 was already deployed, this is a no-op safety net.
     */
    val MIGRATION_8_9 = object : Migration(8, 9) {
        override fun migrate(db: SupportSQLiteDatabase) {
            // Safety: add any columns that might have been added between 8 and 9
            safeAddColumn(db, "media", "currentSpeed", "REAL NOT NULL DEFAULT 0.0")
        }
    }

    /**
     * ✅ NEW: Migration 9→10: Add duration column.
     * Problem 6: Duration not stored in DB → player can't show total time.
     */
    val MIGRATION_ADD_DURATION = object : Migration(9, 10) {
        override fun migrate(db: SupportSQLiteDatabase) {
            safeAddColumn(db, "media", "duration", "INTEGER NOT NULL DEFAULT 0")
            Log.d(TAG, "Migration 9→10: Added duration column")
        }
    }

    private fun safeAddColumn(
        db: SupportSQLiteDatabase,
        table: String,
        column: String,
        definition: String
    ) {
        try {
            db.execSQL("ALTER TABLE $table ADD COLUMN $column $definition")
            Log.d(TAG, "Added column $table.$column")
        } catch (e: Exception) {
            Log.d(TAG, "Column $table.$column already exists: ${e.message}")
        }
    }
}