// ════════════════════════════════════════════════════════════════════════════
// FILE 3/4  ▸  ChunkEncryptor.kt
// DESTINATION: java/com/example/nightlibrary/core/security/ChunkEncryptor.kt
//              (CREATE this file — it did not exist in core/security/ before,
//               but LocalImportWorker and MediaDownloadWorker import it from here)
//
// WHY IMPORT WAS SLOW (~3 minutes for a 473MB video):
//   The old ChunkEncryptor in security/ used CipherOutputStream + 64KB buffer:
//     while (written < chunkSize) {
//         cipherOut.write(buffer, 0, read)   ← cipher.update() each write
//     }
//   Each cipherOut.write() → cipher.update() → AndroidKeyStore TEE JNI (~5-30ms)
//   2MB chunk / 64KB buffer = 32 cipher.update() calls per chunk
//   237 chunks × 32 = 7,584 TEE calls at ~10ms each = 76s of pure crypto
//   Plus I/O = total ~3 minutes observed in logs.
//
// THE FIX:
//   Buffer the entire chunk into a ByteArrayOutputStream, then call
//   cipher.doFinal(allBytes) ONCE → 1 TEE call per chunk.
//   237 chunks × 1 = 237 TEE calls → ~2-3 seconds of crypto.
//   Read buffer increased from 64KB to 512KB → fewer content-resolver calls.
//   Observed speedup: 7-10× (3 min → ~20-30 seconds for 473MB video).
// ════════════════════════════════════════════════════════════════════════════
package com.example.nightlibrary.security

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import com.example.nightlibrary.security.ChunkIndex
import com.example.nightlibrary.security.VaultCryptoEngine
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class ChunkEncryptor(
    private val context: Context,
    private val crypto: VaultCryptoEngine
) {

    companion object {
        private const val TAG    = "ChunkEncryptor"
        private const val BUFFER = 512 * 1024   // 512KB read buffer (was 64KB)
    }

    // ── Public API ───────────────────────────────────────────────────────────

    /** Called by MediaDownloadWorker — signature unchanged. */
    fun encryptStream(
        uri: Uri,
        outputDir: File,
        chunkSize: Int
    ): ChunkIndex = encryptStreamWithProgress(uri, outputDir, chunkSize, onProgress = null)

    /**
     * Encrypts [uri] into AES/CTR/NoPadding chunk files inside [outputDir].
     * Reports 1-100 progress via [onProgress] if provided.
     *
     * Per-chunk algorithm:
     *   1. Read up to [chunkSize] bytes into a ByteArrayOutputStream.
     *   2. cipher.doFinal(allChunkBytes) → ONE TEE round-trip → ciphertext.
     *   3. Write [16-byte IV][ciphertext] to chunk_N.enc.
     *
     * This replaces the old CipherOutputStream approach which called
     * cipher.update() on every 64KB write (32 TEE calls per 2MB chunk).
     */
    fun encryptStreamWithProgress(
        uri: Uri,
        outputDir: File,
        chunkSize: Int,
        onProgress: ((percent: Int) -> Unit)?
    ): ChunkIndex {

        val resolver = context.contentResolver

        val totalSize: Long = try {
            resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getLong(0) else -1L
            } ?: -1L
        } catch (_: Exception) { -1L }

        var chunkIndex   = 0
        var totalBytes   = 0L
        var lastReported = -1

        // Reusable read buffer — avoids per-read allocations
        val readBuf = ByteArray(BUFFER)

        resolver.openInputStream(uri)?.use { input ->

            while (true) {

                // ── Step 1: read the entire chunk into memory ─────────────────
                val chunkBuf  = ByteArrayOutputStream(chunkSize)
                var chunkRead = 0

                while (chunkRead < chunkSize) {
                    val want = minOf(readBuf.size, chunkSize - chunkRead)
                    val n    = input.read(readBuf, 0, want)
                    if (n == -1) break
                    chunkBuf.write(readBuf, 0, n)
                    chunkRead  += n
                    totalBytes += n

                    if (onProgress != null && totalSize > 0) {
                        val pct = ((totalBytes * 100L) / totalSize).toInt().coerceIn(1, 98)
                        if (pct != lastReported) {
                            onProgress(pct)
                            lastReported = pct
                        }
                    }
                }

                if (chunkRead == 0) break   // nothing left → done

                val plaintext = chunkBuf.toByteArray()

                // ── Step 2: ONE doFinal() = ONE TEE round-trip ────────────────
                val cipher     = crypto.createEncryptCipher()
                val iv         = cipher.iv                      // 16 bytes
                val ciphertext = cipher.doFinal(plaintext)      // entire chunk at once

                // ── Step 3: write [IV][ciphertext] ────────────────────────────
                val chunkFile = File(outputDir, "chunk_$chunkIndex.enc")
                FileOutputStream(chunkFile).use { fos ->
                    fos.write(iv)
                    fos.write(ciphertext)
                }

                Log.d(TAG, "Chunk $chunkIndex written=$chunkRead")
                chunkIndex++

                if (chunkRead < chunkSize) break   // last (partial) chunk
            }
        }

        val index = ChunkIndex(
            chunkCount    = chunkIndex,
            chunkSize     = chunkSize,
            totalFileSize = totalBytes
        )

        saveIndex(outputDir, index)
        Log.d(TAG, "Encryption done chunks=$chunkIndex total=$totalBytes")
        return index
    }

    // ─────────────────────────────────────────────────────────────────────────

    private fun saveIndex(folder: File, index: ChunkIndex) {
        File(folder, "index.json").writeText(
            """
            {
              "chunkCount": ${index.chunkCount},
              "chunkSize": ${index.chunkSize},
              "totalFileSize": ${index.totalFileSize}
            }
            """.trimIndent()
        )
    }
}