// ════════════════════════════════════════════════════════════════════
// FIXED BY CLAUDE  ▸  MainActivity.kt
//
// BUG FIXED:
//   Auth was triggered on EVERY onResume() — including when returning
//   from the camera, file picker, dialogs, or navigating between
//   fragments. This caused double-PIN screens, crash from
//   IllegalArgumentException (navigate while already on auth screen),
//   and auth mid-import.
//
// FIX:
//   Use onStop()/onStart() instead of onPause()/onResume() for auth
//   gating. onStop() fires ONLY on genuine background transitions
//   (home button, recents, screen off). Camera, file pickers, dialogs,
//   and fragment nav never call onStop() on the host activity.
// ════════════════════════════════════════════════════════════════════
package com.example.nightlibrary

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
//import com.example.nightlibrary.core.cache.ThumbnailCache
import com.example.nightlibrary.core.media.MediaScanner
import com.example.nightlibrary.databinding.ActivityMainBinding
import com.example.nightlibrary.preferences.SecurityPreferenceManager
import com.example.nightlibrary.security.BiometricMode
import com.example.nightlibrary.security.SecureScreenManager
import com.example.nightlibrary.setting.BaseActivity
import com.example.nightlibrary.setting.VaultSessionManager
import com.example.nightlibrary.worker.PreviewPlayerManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.launch

class MainActivity : BaseActivity() {

    companion object {
        private const val TAG = "MainActivity"
    }

    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    // FIX: simple flag — set in onStop(), cleared in onStart().
    // NO ActivityManager, NO complex process checks needed.
    private var stoppedForBackground = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate")
        setContentView(binding.root)

        SecureScreenManager.enable(this)
        lifecycleScope.launch { MediaScanner.scanVault(this@MainActivity) }
        application.registerComponentCallbacks(PreviewPlayerManager)

        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val wic = WindowCompat.getInsetsController(window, window.decorView)
        wic.hide(WindowInsetsCompat.Type.systemBars())
        wic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val sb = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(sb.left, sb.top, sb.right, 0)
            insets
        }

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.fragmentContainer) as NavHostFragment
        val navController = navHostFragment.navController
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavView)
        NavigationUI.setupWithNavController(bottomNav, navController)

        // Clear thumbnail cache once on cold start only — NOT on every fragment nav
     //   ThumbnailCache.clear()

        navController.addOnDestinationChangedListener { _, destination, _ ->
            Log.d(TAG, "Navigated to: ${destination.label} (${destination.id})")
            bottomNav.visibility = when (destination.id) {
                R.id.homeFragment,
                R.id.libraryFragment,
                R.id.settingsFragment -> View.VISIBLE
                else -> View.GONE
            }
        }
    }

    // FIX: onStop fires ONLY on genuine background transition.
    // Camera/file-picker/dialog returns → onResume only, NOT onStop → no auth triggered.
    override fun onStop() {
        super.onStop()
        // Get the flag from NightLibraryApp
        val app = application as NightLibraryApp

        if (app.isIgnoringNextLock) {
            // DO NOT LOCK. The user is just picking a contact.
            // We don't reset the flag here because NightLibraryApp.onStop will handle it.
            Log.d(TAG, "onStop → Skipping lock because isIgnoringNextLock is TRUE")
            stoppedForBackground = false
        } else if (VaultSessionManager.isUnlocked()) {
            stoppedForBackground = true
            VaultSessionManager.lock()
            Log.d(TAG, "onStop → session LOCKED, stoppedForBackground=true")
        } else {
            Log.d(TAG, "onStop → already locked, no action")
        }
    }

    // FIX: auth triggered in onStart() — only after a genuine background→foreground transition.
    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart → stoppedForBackground=$stoppedForBackground unlocked=${VaultSessionManager.isUnlocked()}")
        if (stoppedForBackground && !VaultSessionManager.isUnlocked()) {
            stoppedForBackground = false
            Log.d(TAG, "onStart → app returned from background, triggering auth")
            openAuthLayer(AuthMode.FULL_LOGIN)
        } else {
            stoppedForBackground = false
        }
    }

    // Keep onResume/onPause empty — no auth logic here at all
    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume — no auth check here (intentional)")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause")
    }

    private fun openAuthLayer(authMode: AuthMode) {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.fragmentContainer) as NavHostFragment
        val navController = navHostFragment.navController

        // Guard: never navigate if already on an auth screen
        val currentId = navController.currentDestination?.id
        if (currentId == R.id.biometricFragment ||
            currentId == R.id.confirmPinFragment ||
            currentId == R.id.splashFragment) {
            Log.d(TAG, "openAuthLayer SKIPPED — already on auth screen id=$currentId")
            return
        }

        val prefs = SecurityPreferenceManager(this)
        Log.d(TAG, "openAuthLayer authMode=$authMode biometric=${prefs.isBiometricEnabled}")

        when (authMode) {
            AuthMode.FULL_LOGIN -> {
                if (prefs.isBiometricEnabled) {
                    navController.navigate(
                        NavGraphDirections.actionGlobalBiometricFragment(BiometricMode.LOGIN)
                    )
                } else {
                    navController.navigate(R.id.action_global_confirmPinFragment)
                }
            }
            AuthMode.INTERRUPT_UNLOCK -> {
                if (prefs.isBiometricEnabled) {
                    navController.navigate(
                        NavGraphDirections.actionGlobalBiometricFragment(BiometricMode.UNLOCK)
                    )
                } else {
                    navController.navigate(R.id.action_global_confirmPinFragment)
                }
            }
        }
    }

    enum class AuthMode {
        FULL_LOGIN,       // App returning from background
        INTERRUPT_UNLOCK  // Quick unlock
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d(TAG, "onSaveInstanceState")
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.fragmentContainer) as NavHostFragment
        navHostFragment.navController.saveState()
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.d(TAG, "onRestoreInstanceState")
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.fragmentContainer) as NavHostFragment
        navHostFragment.navController.restoreState(savedInstanceState)
    }
}
