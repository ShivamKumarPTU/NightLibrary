package com.example.nightlibrary

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.example.nightlibrary.database.VaultDatabase
import com.example.nightlibrary.databinding.FragmentImportMediaBinding
import com.example.nightlibrary.setting.VaultSessionManager
import com.example.nightlibrary.viewmodel.VaultViewModel
import com.example.nightlibrary.worker.ActiveDownloadGuard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ImportMediaFragment : Fragment() {

    companion object {
        private const val TAG = "ImportMediaFragment"
        private const val MAX_BATCH_SIZE = 20
        private const val LARGE_FILE_WARNING_BYTES = 500L * 1024 * 1024
        private const val STORAGE_MULTIPLIER = 3
        private const val MIN_FREE_SPACE_BYTES = 100L * 1024 * 1024
        private const val MAX_IMAGE_DIMENSION = 4096
        private const val MAX_VIDEO_DURATION_SECONDS = 600
        private const val MAX_VIDEO_SIZE_BYTES = 500L * 1024 * 1024
        private const val DCIM_CLEANUP_DELAY_MS = 2000L
    }

    private var _binding: FragmentImportMediaBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: VaultViewModel

    private var cameraPhotoUri: Uri? = null
    private var cameraVideoUri: Uri? = null
    private var captureStartTimestamp: Long = 0L
    private val tempFiles = mutableListOf<File>()

    // ── File picker ──────────────────────────────────────────────
    private val unifiedLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isEmpty()) return@registerForActivityResult
        Log.d(TAG, "File picker returned ${uris.size} uri(s)")

        val validUris = uris.filter { uri ->
            val mime = requireContext().contentResolver.getType(uri)
            if (isMimeTypeSupported(mime)) true
            else {
                Log.w(TAG, "Skipped unsupported mime: $mime")
                false
            }
        }

        if (validUris.isEmpty()) {
            Toast.makeText(context, "No supported files selected", Toast.LENGTH_SHORT).show()
            return@registerForActivityResult
        }

        validateAndStartImport(validUris)
    }

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            val rawUri = cameraPhotoUri ?: return@registerForActivityResult
            cleanDcimShadowCopies("image")

            lifecycleScope.launch(Dispatchers.IO) {
                val normalizedUri = try {
                    normalizeCameraImage(rawUri)
                } catch (e: Exception) {
                    Log.e(TAG, "Image normalization failed: ${e.message}", e)
                    rawUri
                }
                withContext(Dispatchers.Main) {
                    validateAndStartImport(
                        listOf(normalizedUri),
                        overrideMime = "image/jpeg"
                    )
                }
            }
        } else {
            cleanupCameraFile(cameraPhotoUri)
        }
    }

    private val recordVideoLauncher = registerForActivityResult(
        ActivityResultContracts.CaptureVideo()
    ) { success ->
        if (success) {
            val uri = cameraVideoUri ?: return@registerForActivityResult
            cleanDcimShadowCopies("video")

            val fileSize = getFileSizeFromFile(uri)
            if (fileSize > MAX_VIDEO_SIZE_BYTES) {
                Toast.makeText(
                    requireContext(),
                    "Video too large (${fileSize / (1024 * 1024)}MB). Max ${MAX_VIDEO_SIZE_BYTES / (1024 * 1024)}MB.",
                    Toast.LENGTH_LONG
                ).show()
                cleanupCameraFile(uri)
                return@registerForActivityResult
            }

            validateAndStartImport(listOf(uri), overrideMime = "video/mp4")
        } else {
            cleanupCameraFile(cameraVideoUri)
        }
    }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.CAMERA] == true) {
            showCameraChoiceDialog()
        } else {
            Toast.makeText(requireContext(), "Camera permission required", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentImportMediaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = (requireActivity().application as NightLibraryApp)
            .container.vaultViewModelFactory
        viewModel = ViewModelProvider(requireActivity(), factory)[VaultViewModel::class.java]

        VaultSessionManager.resumeDestinationId = R.id.secretVaultFragment

        cleanupIncompleteImports()
        cleanupOrphanedTempFiles()

        binding.cardAddFromGallery.setOnClickListener {
            unifiedLauncher.launch(
                arrayOf("image/*", "video/*", "audio/*", "application/pdf")
            )
        }

        binding.cardCaptureFromCamera.setOnClickListener {
            checkCameraAndLaunch()
        }

        binding.buttonDownloadFromLink.setOnClickListener {
            findNavController().navigate(R.id.action_import_media_to_downloadFormLink)
        }

        binding.toolbarImportMedia.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // VALIDATION
    // ═══════════════════════════════════════════════════════════════

    private fun validateAndStartImport(
        uris: List<Uri>,
        overrideMime: String? = null
    ) {
        val context = requireContext()

        if (uris.size > MAX_BATCH_SIZE) {
            Toast.makeText(
                context,
                "Maximum $MAX_BATCH_SIZE files at once. You selected ${uris.size}.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        lifecycleScope.launch {
            val validationResult = withContext(Dispatchers.IO) {
                performValidation(uris)
            }

            when (validationResult) {
                is ValidationResult.Success -> {
                    if (validationResult.hasLargeFiles) {
                        showLargeFileWarning(
                            validationResult.largeFileNames,
                            validationResult.totalSizeMB
                        ) {
                            enqueueAndNavigate(validationResult.validUris, overrideMime)
                        }
                    } else {
                        enqueueAndNavigate(validationResult.validUris, overrideMime)
                    }
                }
                is ValidationResult.InsufficientStorage -> {
                    Toast.makeText(
                        context,
                        "Not enough storage. Need ${validationResult.neededMB}MB, have ${validationResult.availableMB}MB",
                        Toast.LENGTH_LONG
                    ).show()
                }
                is ValidationResult.AllDuplicates -> {
                    Toast.makeText(
                        context,
                        if (uris.size == 1) "This file is already in your vault"
                        else "All selected files are already in your vault",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                is ValidationResult.PartialDuplicates -> {
                    val skipCount = uris.size - validationResult.validUris.size
                    showDuplicateWarning(skipCount, validationResult.validUris.size) {
                        if (validationResult.hasLargeFiles) {
                            showLargeFileWarning(
                                validationResult.largeFileNames,
                                validationResult.totalSizeMB
                            ) {
                                enqueueAndNavigate(validationResult.validUris, overrideMime)
                            }
                        } else {
                            enqueueAndNavigate(validationResult.validUris, overrideMime)
                        }
                    }
                }
                is ValidationResult.Error -> {
                    Toast.makeText(
                        context,
                        "Validation failed: ${validationResult.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // ✅ NEW: ENQUEUE + NAVIGATE — Replaces blocking dialog
    // ═══════════════════════════════════════════════════════════════

    /**
     * Enqueues import workers and IMMEDIATELY navigates to the
     * In Progress tab. No blocking dialog — user can browse the app
     * while imports run in background.
     */
    private fun enqueueAndNavigate(
        uris: List<Uri>,
        overrideMime: String? = null
    ) {
        val totalFiles = uris.size

        uris.forEach { uri ->
            val mimeType = overrideMime
                ?: requireContext().contentResolver.getType(uri) ?: "*/*"

            var fileName = getFileName(uri)
            if (fileName == null || fileName.startsWith("VAULT_")) {
                val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                fileName = when {
                    mimeType.startsWith("image") -> "IMG_$ts.jpg"
                    mimeType.startsWith("video") -> "VID_$ts.mp4"
                    mimeType.startsWith("audio") -> "AUD_$ts.mp3"
                    else -> "FILE_$ts"
                }
            }

            Log.d(TAG, "Enqueueing: fileName=$fileName mime=$mimeType")

            val inputData = androidx.work.workDataOf(
                "uri" to uri.toString(),
                "mimeType" to mimeType,
                "fileName" to fileName!!
            )

            val request = androidx.work.OneTimeWorkRequestBuilder<
                    com.example.nightlibrary.worker.LocalImportWorker>()
                .setInputData(inputData)
                .build()

            WorkManager.getInstance(requireContext()).enqueue(request)
        }

        Log.d(TAG, "Batch enqueued: $totalFiles files")
        Toast.makeText(context, "Securing $totalFiles item(s)…", Toast.LENGTH_SHORT).show()

        // ✅ Clean up camera temp files
        cleanupAllCameraTempFiles()

        // ✅ Navigate to In Progress tab instead of showing blocking dialog
        findNavController().navigate(
            R.id.secretVaultFragment,
            Bundle().apply { putInt("start_tab", 0) },
            NavOptions.Builder()
                .setPopUpTo(R.id.secretVaultFragment, true)
                .build()
        )
    }

    // ═══════════════════════════════════════════════════════════════
    // VALIDATION HELPERS (unchanged)
    // ═══════════════════════════════════════════════════════════════

    private sealed class ValidationResult {
        data class Success(
            val validUris: List<Uri>, val hasLargeFiles: Boolean,
            val largeFileNames: List<String>, val totalSizeMB: Long
        ) : ValidationResult()
        data class InsufficientStorage(val neededMB: Long, val availableMB: Long) : ValidationResult()
        data object AllDuplicates : ValidationResult()
        data class PartialDuplicates(
            val validUris: List<Uri>, val hasLargeFiles: Boolean,
            val largeFileNames: List<String>, val totalSizeMB: Long
        ) : ValidationResult()
        data class Error(val message: String) : ValidationResult()
    }

    private suspend fun performValidation(uris: List<Uri>): ValidationResult {
        return try {
            val context = requireContext()
            val dao = VaultDatabase.getDatabase(context).mediaDao()
            val validUris = mutableListOf<Uri>()
            val largeFileNames = mutableListOf<String>()
            var totalEstimatedSize = 0L
            var duplicateCount = 0

            for (uri in uris) {
                val fileSize = getFileSize(uri)
                val fingerprint = computeQuickFingerprint(uri)

                if (fingerprint.isNotEmpty() && dao.existsByChecksum(fingerprint)) {
                    duplicateCount++
                    continue
                }

                validUris.add(uri)
                totalEstimatedSize += fileSize

                if (fileSize > LARGE_FILE_WARNING_BYTES) {
                    val name = getFileName(uri) ?: "Unknown file"
                    largeFileNames.add("$name (${fileSize / (1024 * 1024)}MB)")
                }
            }

            if (validUris.isEmpty() && duplicateCount > 0) return ValidationResult.AllDuplicates
            if (validUris.isEmpty()) return ValidationResult.Error("No valid files to import")

            val requiredSpace = totalEstimatedSize * STORAGE_MULTIPLIER
            val availableSpace = getAvailableStorage()

            if (requiredSpace > availableSpace - MIN_FREE_SPACE_BYTES) {
                return ValidationResult.InsufficientStorage(
                    requiredSpace / (1024 * 1024), availableSpace / (1024 * 1024)
                )
            }

            val hasLargeFiles = largeFileNames.isNotEmpty()
            val totalSizeMB = totalEstimatedSize / (1024 * 1024)

            if (duplicateCount > 0) {
                ValidationResult.PartialDuplicates(validUris, hasLargeFiles, largeFileNames, totalSizeMB)
            } else {
                ValidationResult.Success(validUris, hasLargeFiles, largeFileNames, totalSizeMB)
            }
        } catch (e: Exception) {
            ValidationResult.Error(e.message ?: "Unknown error")
        }
    }

    private fun computeQuickFingerprint(uri: Uri): String {
        return try {
            val resolver = requireContext().contentResolver
            val md = java.security.MessageDigest.getInstance("SHA-256")
            val fileSize: Long = try {
                resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val idx = c.getColumnIndex(OpenableColumns.SIZE)
                        if (idx != -1) c.getLong(idx) else -1L
                    } else -1L
                } ?: -1L
            } catch (_: Exception) { -1L }

            resolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(8192)
                var totalRead = 0L
                while (totalRead < 1024 * 1024L) {
                    val n = input.read(buffer)
                    if (n == -1) break
                    md.update(buffer, 0, n)
                    totalRead += n
                }
            }
            md.update(fileSize.toString().toByteArray(Charsets.UTF_8))
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) { "" }
    }

    // ═══════════════════════════════════════════════════════════════
    // WARNING DIALOGS
    // ═══════════════════════════════════════════════════════════════

    private fun showLargeFileWarning(
        largeFileNames: List<String>, totalSizeMB: Long, onProceed: () -> Unit
    ) {
        val fileList = largeFileNames.joinToString("\n") { "  • $it" }
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Large Files Detected")
            .setMessage("Large files:\n\n$fileList\n\nTotal: ~${totalSizeMB}MB\n\nContinue?")
            .setPositiveButton("Import") { d, _ -> d.dismiss(); onProceed() }
            .setNegativeButton("Cancel") { d, _ -> d.dismiss() }
            .show()
    }

    private fun showDuplicateWarning(skipCount: Int, importCount: Int, onProceed: () -> Unit) {
        val dupText = if (skipCount == 1) "1 file is" else "$skipCount files are"
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Duplicates Found")
            .setMessage("$dupText already in vault.\n\n$importCount new file(s) will be imported.")
            .setPositiveButton("Continue") { d, _ -> d.dismiss(); onProceed() }
            .setNegativeButton("Cancel") { d, _ -> d.dismiss() }
            .show()
    }

    // ═══════════════════════════════════════════════════════════════
    // STORAGE / FILE HELPERS
    // ═══════════════════════════════════════════════════════════════

    private fun getAvailableStorage(): Long = try {
        val stat = StatFs(requireContext().filesDir.absolutePath)
        stat.availableBlocksLong * stat.blockSizeLong
    } catch (_: Exception) { Long.MAX_VALUE }

    private fun getFileSize(uri: Uri): Long = try {
        requireContext().contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)
            ?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.SIZE)
                    if (idx != -1) c.getLong(idx) else 0L
                } else 0L
            } ?: 0L
    } catch (_: Exception) { 0L }

    private fun getFileSizeFromFile(uri: Uri): Long = try {
        uri.path?.let { File(it).let { f -> if (f.exists()) f.length() else getFileSize(uri) } }
            ?: getFileSize(uri)
    } catch (_: Exception) { 0L }

    private fun isMimeTypeSupported(mimeType: String?): Boolean {
        if (mimeType == null) return false
        return mimeType.startsWith("image/") || mimeType.startsWith("video/") ||
                mimeType.startsWith("audio/") || mimeType == "application/pdf"
    }

    private fun getFileName(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            requireContext().contentResolver.query(uri, null, null, null, null)?.use {
                if (it.moveToFirst()) {
                    val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index != -1) result = it.getString(index)
                }
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/') ?: -1
            if (cut != -1) result = result?.substring(cut + 1)
        }
        return result
    }

    // ═══════════════════════════════════════════════════════════════
    // CAMERA FLOW (unchanged)
    // ═══════════════════════════════════════════════════════════════

    private fun checkCameraAndLaunch() {
        val camOk = ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (camOk) showCameraChoiceDialog()
        else cameraPermissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
    }

    private fun showCameraChoiceDialog() {
        val options = arrayOf(
            "📷  Take Photo",
            "🎥  Record Video (max ${MAX_VIDEO_DURATION_SECONDS / 60} min)"
        )
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Capture From Camera")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> launchPhotoCapture()
                    1 -> launchVideoCapture()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun launchPhotoCapture() {
        try {
            captureStartTimestamp = System.currentTimeMillis()
            val photoFile = createTempMediaFile(suffix = ".jpg")
            tempFiles.add(photoFile)
            val uri = FileProvider.getUriForFile(
                requireContext(), "${requireContext().packageName}.fileprovider", photoFile
            )
            cameraPhotoUri = uri
            takePictureLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Could not open camera", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchVideoCapture() {
        try {
            captureStartTimestamp = System.currentTimeMillis()
            val videoFile = createTempMediaFile(suffix = ".mp4")
            tempFiles.add(videoFile)
            val uri = FileProvider.getUriForFile(
                requireContext(), "${requireContext().packageName}.fileprovider", videoFile
            )
            cameraVideoUri = uri
            recordVideoLauncher.launch(uri)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Could not open camera", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createTempMediaFile(suffix: String): File {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val dir = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            ?: requireContext().cacheDir
        dir.mkdirs()
        return File.createTempFile("VAULT_${ts}_", suffix, dir)
    }

    private fun cleanupCameraFile(uri: Uri?) {
        if (uri == null) return
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                uri.path?.let { path ->
                    val file = File(path)
                    if (file.exists()) file.delete()
                }
            } catch (_: Exception) {}
        }
    }

    private fun cleanupAllCameraTempFiles() {
        lifecycleScope.launch(Dispatchers.IO) {
            tempFiles.forEach { file ->
                try { if (file.exists()) file.delete() } catch (_: Exception) {}
            }
            tempFiles.clear()
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // DCIM SHADOW CLEANUP (unchanged)
    // ═══════════════════════════════════════════════════════════════

    private fun cleanDcimShadowCopies(mediaType: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            kotlinx.coroutines.delay(DCIM_CLEANUP_DELAY_MS)
            try {
                val resolver = requireContext().contentResolver
                val collection = if (mediaType == "image") {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

                val dateColumn = if (mediaType == "image") {
                    MediaStore.Images.Media.DATE_ADDED
                } else MediaStore.Video.Media.DATE_ADDED

                val dataColumn = if (mediaType == "image") {
                    MediaStore.Images.Media.DATA
                } else MediaStore.Video.Media.DATA

                val captureTimeSec = captureStartTimestamp / 1000L

                resolver.query(
                    collection,
                    arrayOf(MediaStore.MediaColumns._ID, dataColumn, dateColumn),
                    "$dateColumn >= ?",
                    arrayOf(captureTimeSec.toString()),
                    "$dateColumn DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                    val pathCol = cursor.getColumnIndex(dataColumn)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val path = if (pathCol >= 0) cursor.getString(pathCol) else null

                        val isDcimShadow = path != null && (
                                path.contains("/DCIM/") || path.contains("/Camera/") ||
                                        path.contains("/Pictures/"))
                        val isOurFile = path != null && path.contains("VAULT_")

                        if (isDcimShadow && !isOurFile) {
                            try {
                                val deleteUri = android.content.ContentUris.withAppendedId(collection, id)
                                resolver.delete(deleteUri, null, null)
                                path?.let { File(it).takeIf { f -> f.exists() }?.delete() }
                            } catch (_: SecurityException) {
                            } catch (_: Exception) {}
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // NORMALIZE CAMERA IMAGE (unchanged)
    // ═══════════════════════════════════════════════════════════════

    private fun normalizeCameraImage(uri: Uri): Uri {
        val context = requireContext()
        val resolver = context.contentResolver

        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, boundsOpts) }

        val rawWidth = boundsOpts.outWidth
        val rawHeight = boundsOpts.outHeight
        if (rawWidth <= 0 || rawHeight <= 0) return uri

        var sampleSize = 1
        if (rawWidth > MAX_IMAGE_DIMENSION || rawHeight > MAX_IMAGE_DIMENSION) {
            var halfW = rawWidth / 2; var halfH = rawHeight / 2
            while (halfW / sampleSize >= MAX_IMAGE_DIMENSION || halfH / sampleSize >= MAX_IMAGE_DIMENSION) {
                sampleSize *= 2
            }
        }

        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bitmap = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOpts)
        } ?: return uri

        val rotatedBitmap = try {
            val exifStream = resolver.openInputStream(uri)
            if (exifStream != null) {
                val exif = androidx.exifinterface.media.ExifInterface(exifStream)
                exifStream.close()
                val orientation = exif.getAttributeInt(
                    androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
                )
                val degrees = when (orientation) {
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
                if (degrees != 0f) {
                    val matrix = Matrix().apply { postRotate(degrees) }
                    val rotated = Bitmap.createBitmap(
                        bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true
                    )
                    if (rotated !== bitmap) bitmap.recycle()
                    rotated
                } else bitmap
            } else bitmap
        } catch (e: Exception) {
            Log.w(TAG, "EXIF rotation failed: ${e.message}")
            bitmap
        }

        val outFile = File(context.cacheDir, "normalized_${System.currentTimeMillis()}.jpg")
        tempFiles.add(outFile)

        try {
            FileOutputStream(outFile).use { fos ->
                rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, 92, fos)
            }
        } finally {
            rotatedBitmap.recycle()
        }

        return outFile.toUri()
    }

    // ═══════════════════════════════════════════════════════════════
    // CLEANUP
    // ═══════════════════════════════════════════════════════════════

    /**
     * ⚡ Bug 3 fix: Cleanup incomplete imports WITHOUT deleting active downloads.
     *
     * Before: Deleted ALL temp files → killed active downloads
     * After:  Checks ActiveDownloadGuard before deleting anything
     */
    /**
     * ⚡ Bug 3 fix: Cleanup incomplete imports WITHOUT deleting active downloads.
     *
     * Before: Deleted ALL temp files → killed active downloads
     * After:  Checks ActiveDownloadGuard before deleting anything
     */
    private fun cleanupIncompleteImports() {
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            try {
                // ⚡ Bug 3: Create guard BEFORE iterating files
                val guard = ActiveDownloadGuard(requireContext())

                val tempDirs = listOf(
                    File(requireContext().filesDir, "vault_downloads"),
                    File(requireContext().filesDir, "vault_media/temp"),
                    requireContext().cacheDir
                )

                var cleaned = 0
                var skipped = 0

                for (dir in tempDirs) {
                    if (!dir.exists()) continue

                    dir.listFiles()?.forEach { file ->
                        if (guard.isSafeToDelete(file.name)) {
                            // Also check file age — only delete if older than 5 minutes
                            val ageMs = System.currentTimeMillis() - file.lastModified()
                            if (ageMs > 5 * 60 * 1000L) {
                                file.delete()
                                cleaned++
                                Log.d(TAG, "Cleaned up: ${file.name}")
                            }
                        } else {
                            skipped++
                            Log.d(TAG, "⚡ Skipped active download: ${file.name}")
                        }
                    }
                }

                if (cleaned > 0 || skipped > 0) {
                    Log.d(TAG, "Cleanup: deleted=$cleaned skipped=$skipped active files")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Cleanup failed: ${e.message}")
            }
        }
    }
    private fun cleanupOrphanedTempFiles() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val ctx = requireContext()
                var cleaned = 0

                ctx.cacheDir.listFiles()?.forEach { file ->
                    if (file.name.startsWith("normalized_") && file.isFile) {
                        val ageMs = System.currentTimeMillis() - file.lastModified()
                        if (ageMs > 60 * 60 * 1000L) {
                            file.delete()
                            cleaned++
                        }
                    }
                }

                val picturesDir = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                picturesDir?.listFiles()?.forEach { file ->
                    if (file.name.startsWith("VAULT_") && file.isFile) {
                        val ageMs = System.currentTimeMillis() - file.lastModified()
                        if (ageMs > 60 * 60 * 1000L) {
                            file.delete()
                            cleaned++
                        }
                    }
                }

                val tempDir = File(ctx.filesDir, "vault_media/temp")
                if (tempDir.exists()) {
                    tempDir.listFiles()?.forEach { dir ->
                        val ageMs = System.currentTimeMillis() - dir.lastModified()
                        if (ageMs > 60 * 60 * 1000L) {
                            dir.deleteRecursively()
                            cleaned++
                        }
                    }
                }

                if (cleaned > 0) {
                    Log.d(TAG, "Cleaned $cleaned orphaned temp file(s)")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Orphaned temp cleanup error: ${e.message}")
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // LIFECYCLE
    // ═══════════════════════════════════════════════════════════════

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onDestroy() {
        super.onDestroy()
        tempFiles.forEach { file ->
            try { if (file.exists()) file.delete() } catch (_: Exception) {}
        }
        tempFiles.clear()
    }
}
