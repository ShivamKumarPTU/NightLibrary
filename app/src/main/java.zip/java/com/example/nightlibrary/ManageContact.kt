package com.example.nightlibrary

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.nightlibrary.adapter.ContactAdapter
import com.example.nightlibrary.databinding.DialogDeleteConfirmationBinding
import com.example.nightlibrary.databinding.DialogDeletePhotoBinding
import com.example.nightlibrary.databinding.FragmentManageContactBinding
import com.example.nightlibrary.entity.ContactEntity
import com.example.nightlibrary.entity.MediaEntity
import com.example.nightlibrary.viewmodel.VaultViewModel
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class ManageContact : Fragment() {

    companion object {
        private const val TAG = "ManageContact"
        private const val TAG_ADD_SHEET = "AddContactBottomSheet"
        private const val TAG_EDIT_SHEET = "EditContactBottomSheet"
    }

    private var _binding: FragmentManageContactBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: VaultViewModel
    private lateinit var adapter: ContactAdapter

    // ═══════════════════════════════════════════════════════════════
    // BACK PRESS — exits selection mode first
    // ═══════════════════════════════════════════════════════════════

    private val backPressCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            viewModel.clearContactSelection()
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // CONTACT IMPORT — permission + picker
    // ═══════════════════════════════════════════════════════════════

    private val contactPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            openContactPicker()
        } else {
            Toast.makeText(requireContext(), "Permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    private val contactPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri -> processSelectedContact(uri) }
        }
    }

    // Called by AddContactBottomSheet
    fun checkContactPermission() {
        if (ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.READ_CONTACTS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            openContactPicker()
        } else {
            contactPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    private fun openContactPicker() {
        val intent = Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI)
        contactPickerLauncher.launch(intent)
    }

    fun processSelectedContact(contactUri: android.net.Uri) {
        try {
            val projection = arrayOf(
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY
            )

            requireContext().contentResolver.query(contactUri, projection, null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val contactId = cursor.getString(
                            cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
                        )
                        val name = cursor.getString(
                            cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
                        ) ?: ""

                        // Get phone number
                        var phone = ""
                        requireContext().contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                            "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                            arrayOf(contactId),
                            null
                        )?.use { pc ->
                            if (pc.moveToFirst()) {
                                phone = pc.getString(0) ?: ""
                            }
                        }

                        if (name.isNotBlank() && phone.isNotBlank()) {
                            viewModel.addContact(name, phone, null)
                            Toast.makeText(
                                requireContext(), "$name imported", Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                requireContext(), "Contact has no phone number", Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Import failed: ${e.message}")
            Toast.makeText(requireContext(), "Import failed", Toast.LENGTH_SHORT).show()
        }

        // Dismiss the add bottom sheet
        (childFragmentManager.findFragmentByTag(TAG_ADD_SHEET) as? BottomSheetDialogFragment)
            ?.dismiss()
    }

    // ═══════════════════════════════════════════════════════════════
    // LIFECYCLE
    // ═══════════════════════════════════════════════════════════════

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentManageContactBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = (requireActivity().application as NightLibraryApp)
            .container.vaultViewModelFactory
        viewModel = ViewModelProvider(requireActivity(), factory)[VaultViewModel::class.java]

        setupToolbar()
        setupRecyclerView()
        setupFab()
        setupSelectionActions()
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, backPressCallback)
        observeData()
    }

    override fun onDestroyView() {
        viewModel.clearContactSelection()
        super.onDestroyView()
        _binding = null
    }

    // ═══════════════════════════════════════════════════════════════
    // TOOLBAR
    // ═══════════════════════════════════════════════════════════════

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            if (viewModel.isContactSelectionMode.value) {
                viewModel.clearContactSelection()
            } else {
                findNavController().navigateUp()
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // RECYCLERVIEW
    // ═══════════════════════════════════════════════════════════════

    private fun setupRecyclerView() {
        adapter = ContactAdapter(
            onMenuClickListener = { contact, anchor ->
                showContactMenu(contact, anchor)
            },
            onItemClick = { contact ->
                if (viewModel.isContactSelectionMode.value) {
                    viewModel.toggleContactSelection(contact.id)
                }
            },
            onItemLongClick = { contact ->
                viewModel.toggleContactSelection(contact.id)
            }
        )
        binding.contactsRecycler.layoutManager = LinearLayoutManager(requireContext())
        binding.contactsRecycler.adapter = adapter
    }

    // ═══════════════════════════════════════════════════════════════
    // FAB
    // ═══════════════════════════════════════════════════════════════

    private fun setupFab() {
        binding.fabAdd.setOnClickListener {
            if (viewModel.isContactSelectionMode.value) {
                viewModel.selectAllContacts()
            } else {
                AddContactBottomSheet().show(childFragmentManager, TAG_ADD_SHEET)
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // SELECTION ACTION BAR
    // ═══════════════════════════════════════════════════════════════

    private fun setupSelectionActions() {
        binding.btnCancelSelection.setOnClickListener {
            viewModel.clearContactSelection()
        }

        binding.btnShareSelected.setOnClickListener {
            val text = viewModel.shareSelectedContacts()
            if (text.isNotBlank()) {
                viewModel.launchTextShare(text, "Share Contacts")
                viewModel.clearContactSelection()
            }
        }

        binding.btnDeleteSelected.setOnClickListener {
            val count = viewModel.selectedContactIds.value.size
         val db = DialogDeleteConfirmationBinding.inflate(layoutInflater)
             val dialog = AlertDialog.Builder(requireContext()).setView(db.root).create()
                db.dialogTitle.text="Delete $count contact${if (count != 1) "s" else ""}?"
              db.deleteConfirmationText.text = "Are you sure you want to delete your contacts permanently? This action cannot be undone."
            db.cancelButton.setOnClickListener{dialog.dismiss()}
              db.deleteButton.setOnClickListener { viewModel.deleteSelectedContacts() }
            dialog.window?.setDimAmount(0.75f)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window?.setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
            )
            dialog.show()
        }

    }

    // ═══════════════════════════════════════════════════════════════
    // OBSERVE DATA
    // ═══════════════════════════════════════
    private fun observeData() {
        // Contacts list
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.contacts.collectLatest { list ->
                adapter.submitList(list)
            }
        }

        // Count text
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.contactCount.collectLatest { count ->
                if (_binding != null) {
                    binding.contactCountText.text =
                        "$count contact${if (count != 1) "s" else ""}"
                }
            }
        }

        // Selection state → UI
        viewLifecycleOwner.lifecycleScope.launch {
            combine(
                viewModel.selectedContactIds,
                viewModel.isContactSelectionMode
            ) { ids, selecting -> Pair(ids, selecting) }
                .collectLatest { (ids, selecting) ->
                    if (_binding == null) return@collectLatest

                    adapter.updateSelectedItems(ids)
                    binding.selectionActionsLayout.isVisible = selecting
                    binding.fabAdd.isVisible = !selecting
                    backPressCallback.isEnabled = selecting

                    if (selecting) {
                        val total = viewModel.contacts.value.size
                        binding.toolbar.title = "${ids.size} selected"
                        binding.toolbar.setNavigationIcon(R.drawable.ic_cross)
                        binding.contactCountText.text = "${ids.size} of $total selected"
                    } else {
                        binding.toolbar.title = "Private Contacts"
                        binding.toolbar.setNavigationIcon(R.drawable.ic_arrow_left_with_bg)
                    }
                }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // POPUP MENU (single item 3-dot)
    // ═══════════════════════════════════════════════════════════════

    private fun showContactMenu(contact: ContactEntity, anchor: View) {
        val popup = PopupMenu(requireContext(), anchor)
        popup.menuInflater.inflate(R.menu.menu_contact_item, popup.menu)
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_select -> {
                    viewModel.toggleContactSelection(contact.id)
                    true
                }
                R.id.action_edit -> {
                    EditContactBottomSheet.newInstance(contact)
                        .show(childFragmentManager, TAG_EDIT_SHEET)
                    true
                }
                R.id.action_share -> {
                    val text = buildString {
                        appendLine(contact.name)
                        appendLine(contact.phone)
                        if (!contact.notes.isNullOrBlank()) appendLine(contact.notes)
                    }
                    viewModel.launchTextShare(text, "Share Contact")
                    true
                }
                R.id.action_delete -> {
                    val count = viewModel.selectedContactIds.value.size
                    val db = DialogDeleteConfirmationBinding.inflate(layoutInflater)
                    val dialog = AlertDialog.Builder(requireContext()).setView(db.root).create()
                    db.dialogTitle.text="Delete 1 Contact ?"
                    db.deleteConfirmationText.text = "Are you sure you want to delete your contact permanently? This action cannot be undone."
                    db.cancelButton.setOnClickListener{dialog.dismiss()}
                    db.deleteButton.setOnClickListener { viewModel.deleteSelectedContacts() }
                    dialog.window?.setDimAmount(0.75f)
                    dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                    dialog.window?.setFlags(
                        WindowManager.LayoutParams.FLAG_SECURE,
                        WindowManager.LayoutParams.FLAG_SECURE
                    )
                    dialog.show()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }
}