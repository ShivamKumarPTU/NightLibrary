package com.example.nightlibrary.setting

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.nightlibrary.MainActivity

class DialerCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "android.provider.Telephony.SECRET_CODE") {
            val uri = intent.data

            // Check if it's #*123 (host will be "123")
            if (uri != null && uri.host == "123") {

                // Launch your app
                val launchIntent = Intent(context, MainActivity::class.java)
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                launchIntent.putExtra("from_dialer", true)
                context.startActivity(launchIntent)
            }
        }
    }
}