package com.example.nightlibrary

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.nightlibrary.databinding.FragmentReadingBinding

class ReadingFragment : Fragment() {
    private var _binding: FragmentReadingBinding? = null
    private val binding get() = _binding!!

    // --- We will use only these variables for the secret vault logic ---
    private var secretClickCount = 0
    private val requiredClicks = 5
    private var isNavigating = false
    private val resetHandler = Handler(Looper.getMainLooper())
    private val resetRunnable = Runnable {
        secretClickCount = 0
    }
    // --- End of variable declarations ---

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReadingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val navController = findNavController()
        binding.toolbarReading.setNavigationOnClickListener {
            navController.popBackStack()
        }

        // --- THIS IS THE FIX ---
        // We only need ONE listener on the parent layout.
        // Clicks on the EditText inside will bubble up to this listener.
        binding.searchEditText.setOnClickListener {
            // Call our consolidated logic function
            handleSecretVaultClick()
        }
        // REMOVED the separate listener for searchEditText
    }

    private fun handleSecretVaultClick() {
        if (isNavigating) return  // prevent double execution
        // 1. Reset the timeout timer
        resetHandler.removeCallbacks(resetRunnable)

        // 2. Increment the single, correct counter
        secretClickCount++

        // 3. Calculate how many clicks are left
        val clicksLeft = requiredClicks - secretClickCount

        if (clicksLeft > 0) {
            // Show the correct number of clicks left
            binding.secretStatusText.text = "Clicks left to unlock: $clicksLeft"
            binding.secretStatusText.animate()
                .alpha(1f)
                .setDuration(100)
                .start()
        } else {
            isNavigating = true
            binding.secretStatusText.text = "Unlocked "
            // Navigate only when clicksLeft is 0 or less
            findNavController().navigate(R.id.action_readingFragment_to_secretVaultFragment)
            // Reset the counter immediately after navigating
            secretClickCount = 0
        }

        // 4. Set the timer to reset the count after 2 seconds of inactivity
        resetHandler.removeCallbacksAndMessages(null) // clear previous timers
        resetHandler.postDelayed({
            if (_binding != null) {
                binding.secretStatusText.animate()
                    .alpha(0f)
                    .setDuration(200)
                    .start()
            }
            secretClickCount = 0

        }, 5000)
    }

    // REMOVED the old navigateToSecretVault() function as its logic is now in handleSecretVaultClick()

    override fun onDestroyView() {
        super.onDestroyView()
        resetHandler.removeCallbacks(resetRunnable)
        _binding = null
    }

    override fun onResume() {
        super.onResume()
        // Reset all logic flags so the user can trigger the secret vault again
        isNavigating = false
        secretClickCount = 0

        // Hide the status text immediately when returning
        binding.secretStatusText.alpha = 0f
        binding.secretStatusText.text = ""

        // Clear any pending reset timers from previous attempts
        resetHandler.removeCallbacksAndMessages(null)
    }
}