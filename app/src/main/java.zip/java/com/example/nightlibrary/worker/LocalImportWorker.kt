package com.example.nightlibrary.worker

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.nightlibrary.core.security.VaultFileManager
import com.example.nightlibrary.database.VaultDatabase
import com.example.nightlibrary.entity.MediaEntity
import com.example.nightlibrary.security.ChunkEncryptor
import com.example.nightlibrary.security.VaultCryptoEngine
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID

class LocalImportWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG = "LocalImportWorker"
        private const val VIDEO_CHUNK_SIZE = 4 * 1024 * 1024
        private const val OTHER_CHUNK_SIZE = 512 * 1024

        private const val FINGERPRINT_READ_LIMIT = 1024 * 1024L
        private const val FINGERPRINT_BUFFER_SIZE = 8192
    }

    override suspend fun doWork(): Result {
        val uriString = inputData.getString("uri") ?: return Result.failure()
        val mimeType = inputData.getString("mimeType") ?: return Result.failure()
        val fileName = inputData.getString("fileName") ?: "imported_file"
        val filePath = inputData.getString("filePath")
        val uri: Uri = if (!filePath.isNullOrEmpty()) Uri.fromFile(File(filePath))
        else Uri.parse(uriString)

        val db = VaultDatabase.getDatabase(applicationContext)
        val dao = db.mediaDao()

        var mediaId = 0L
        var tempVaultFolder: File? = null
        var finalVaultFolder: File? = null
        var isCompleted = false

        return try {
            val fileType = resolveType(mimeType)

            // Step 1 — Compute content fingerprint
            val fingerprint = computeContentFingerprint(uri)
            Log.d(TAG, "Fingerprint for $fileName: ${fingerprint.take(16)}…")

            // Step 2 — Check for duplicate
            if (fingerprint.isNotEmpty() && dao.existsByChecksum(fingerprint)) {
                Log.d(TAG, "⚠️ Duplicate detected, skipping: $fileName")
                return Result.success(
                    workDataOf(
                        "result" to "DUPLICATE",
                        "fileName" to fileName
                    )
                )
            }

            // Step 3 — Create temp vault folder
            tempVaultFolder = File(
                applicationContext.filesDir,
                "vault_media/temp/${UUID.randomUUID()}"
            ).also { it.mkdirs() }

            // ✅ IMPROVED: Get file size early for progress display
            val fileSize = getFileSize(uri)

            mediaId = dao.insertAndGetId(
                MediaEntity(
                    fileName = fileName,
                    vaultFolder = tempVaultFolder!!.absolutePath,
                    chunkCount = 0,
                    chunkSize = 0,
                    fileSize = fileSize,
                    mimeType = mimeType,
                    fileType = fileType,
                    isCompleted = false,
                    progress = 0,
                    checksum = fingerprint,
                    filePath = "",
                    thumbnailPath = null,
                    // ✅ NEW: No download URL = appears in "Imports" section
                    downloadUrl = null,
                    currentSpeed = 0.0
                )
            )

            // ✅ NEW: Report initial progress — item now appears in In Progress tab
            setProgressAsync(workDataOf("progress" to 1, "mediaId" to mediaId))
            dao.updateProgress(mediaId, 1, 0L)

            // Step 4 — Create final vault folder
            finalVaultFolder = File(
                applicationContext.filesDir,
                "vault_media/$fileType/${UUID.randomUUID()}"
            ).also { it.mkdirs() }

            val thumbDeferred: Deferred<String?>
            var totalSize = 0L
            var chunkCount = 0

            coroutineScope {
                thumbDeferred = async(Dispatchers.IO) {
                    // ✅ NEW: Report thumbnail generation stage
                    dao.updateProgress(mediaId, 5, 0L)
                    setProgressAsync(workDataOf("progress" to 5, "mediaId" to mediaId))
                    generateThumbnail(uri, mimeType, mediaId)
                }

                if (fileType == "image") {
                    // ✅ IMPROVED: Report stages for image import
                    dao.updateProgress(mediaId, 10, 0L)
                    setProgressAsync(workDataOf("progress" to 10, "mediaId" to mediaId))

                    val vaultFileManager = VaultFileManager(applicationContext)
                    val encryptedFile = vaultFileManager.encryptToDirectory(
                        uri, finalVaultFolder!!, "full_image.enc"
                    )
                    totalSize = encryptedFile.length()
                    chunkCount = 1

                    dao.updateProgress(mediaId, 95, 0L)
                    setProgressAsync(workDataOf("progress" to 95, "mediaId" to mediaId))
                } else {
                    val encryptor = ChunkEncryptor(
                        applicationContext, VaultCryptoEngine()
                    )
                    val chunkSize = if (fileType == "video")
                        VIDEO_CHUNK_SIZE else OTHER_CHUNK_SIZE

                    // ✅ IMPROVED: Report progress every 2% instead of 5%
                    var lastReportedPct = 0
                    val index = encryptor.encryptStreamWithProgress(
                        uri, finalVaultFolder!!, chunkSize
                    ) { pct ->
                        // Scale to 10-95 range (0-10 is thumbnail, 95-100 is finalize)
                        val scaledPct = 10 + (pct * 85 / 100)
                        if (scaledPct - lastReportedPct >= 2) {
                            lastReportedPct = scaledPct
                            setProgressAsync(
                                workDataOf("progress" to scaledPct, "mediaId" to mediaId)
                            )
                            runBlocking {
                                dao.updateProgress(mediaId, scaledPct, 0L)
                            }
                        }
                    }
                    totalSize = index.totalFileSize
                    chunkCount = index.chunkCount
                }
            }

            val thumbnailPath = thumbDeferred.await()

            // ✅ NEW: Report finalizing stage
            dao.updateProgress(mediaId, 98, 0L)
            setProgressAsync(workDataOf("progress" to 98, "mediaId" to mediaId))

            dao.update(
                MediaEntity(
                    id = mediaId,
                    fileName = fileName,
                    vaultFolder = finalVaultFolder!!.absolutePath,
                    chunkCount = chunkCount,
                    chunkSize = if (fileType == "video")
                        VIDEO_CHUNK_SIZE else OTHER_CHUNK_SIZE,
                    fileSize = totalSize,
                    mimeType = mimeType,
                    fileType = fileType,
                    isCompleted = true,
                    progress = 100,
                    checksum = fingerprint,
                    filePath = "",
                    thumbnailPath = thumbnailPath,
                    downloadUrl = null,
                    currentSpeed = 0.0
                )
            )

            isCompleted = true
            Result.success(
                workDataOf(
                    "result" to "SUCCESS",
                    "mediaId" to mediaId
                )
            )

        } catch (e: Exception) {
            Log.e(TAG, "Import failed: ${e.message}", e)
            Result.failure(
                workDataOf("error" to (e.message ?: "Unknown error"))
            )
        } finally {
            // Always clean temp folder
            try {
                tempVaultFolder?.deleteRecursively()
            } catch (_: Exception) {}

            // If import didn't complete, clean up everything
            if (!isCompleted && mediaId > 0) {
                Log.d(TAG, "Cleaning up failed import: mediaId=$mediaId")
                try {
                    finalVaultFolder?.deleteRecursively()
                } catch (_: Exception) {}
                try {
                    dao.deleteById(mediaId)
                } catch (_: Exception) {}
                try {
                    val thumbFile = File(
                        applicationContext.filesDir,
                        "vault_thumbs/thumb_$mediaId.jpg"
                    )
                    if (thumbFile.exists()) thumbFile.delete()
                } catch (_: Exception) {}
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // CONTENT FINGERPRINTING
    // ─────────────────────────────────────────────────────────────────────

    private fun computeContentFingerprint(uri: Uri): String {
        return try {
            val resolver = applicationContext.contentResolver
            val md = MessageDigest.getInstance("SHA-256")

            val fileSize: Long = try {
                resolver.query(
                    uri,
                    arrayOf(OpenableColumns.SIZE),
                    null, null, null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (idx != -1) cursor.getLong(idx) else -1L
                    } else -1L
                } ?: -1L
            } catch (_: Exception) {
                -1L
            }

            resolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(FINGERPRINT_BUFFER_SIZE)
                var totalRead = 0L
                while (totalRead < FINGERPRINT_READ_LIMIT) {
                    val n = input.read(buffer)
                    if (n == -1) break
                    md.update(buffer, 0, n)
                    totalRead += n
                }
            }

            md.update(fileSize.toString().toByteArray(Charsets.UTF_8))
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            Log.w(TAG, "Fingerprint failed: ${e.message}")
            ""
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // ✅ NEW: Get file size for early display in In Progress tab
    // ─────────────────────────────────────────────────────────────────────

    private fun getFileSize(uri: Uri): Long {
        return try {
            applicationContext.contentResolver.query(
                uri, arrayOf(OpenableColumns.SIZE), null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (idx != -1) cursor.getLong(idx) else 0L
                } else 0L
            } ?: 0L
        } catch (_: Exception) { 0L }
    }

    // ─────────────────────────────────────────────────────────────────────

    private fun generateThumbnail(
        uri: Uri, mimeType: String, id: Long
    ): String? {
        return try {
            val thumbDir = File(
                applicationContext.filesDir, "vault_thumbs"
            ).also { it.mkdirs() }
            val thumbFile = File(thumbDir, "thumb_$id.jpg")

            val bitmap: Bitmap? = when {
                mimeType.startsWith("image") -> {
                    applicationContext.contentResolver
                        .openInputStream(uri)?.use { input ->
                            BitmapFactory.decodeStream(
                                input, null,
                                BitmapFactory.Options().apply {
                                    inSampleSize = 2
                                }
                            )
                        }
                }

                mimeType.startsWith("video") -> {
                    MediaMetadataRetriever().use { retriever ->
                        retriever.setDataSource(applicationContext, uri)
                        retriever.getFrameAtTime(
                            0,
                            MediaMetadataRetriever.OPTION_NEXT_SYNC
                        )
                    }
                }

                else -> null
            }

            if (bitmap != null) {
                FileOutputStream(thumbFile).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
                bitmap.recycle()
                thumbFile.absolutePath
            } else null
        } catch (e: Exception) {
            Log.w(TAG, "Thumbnail generation failed: ${e.message}")
            null
        }
    }

    private fun resolveType(mime: String): String = when {
        mime.startsWith("image") -> "image"
        mime.startsWith("video") -> "video"
        mime.startsWith("audio") -> "audio"
        mime == "application/pdf" -> "pdf"
        else -> "document"
    }
}