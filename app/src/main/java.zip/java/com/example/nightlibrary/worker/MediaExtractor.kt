package com.example.nightlibrary.worker

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.nightlibrary.model.FormatInfo
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

data class VideoInfo(
    val streamUrl: String,
    val pageUrl: String,
    val headers: Map<String, String> = emptyMap(),
    val useYtDlp: Boolean = false,
    val formatId: String? = null,
    val isHls: Boolean = false,
    val fileSize: Long = -1L,
    val contentType: String? = null,
    val duration: Long = 0L,          // ← Problem 6: seconds
    val fileType: String = "video",   // ← Feature A: "audio" or "video"
    val hasAudio: Boolean = true      // ← Problem 2: accurate audio flag
)

sealed class ExtractResult {
    data class Success(val json: String) : ExtractResult()
    data class Error(val message: String) : ExtractResult()
}

/**
 * MediaExtractor — Optimized hybrid extractor.
 *
 * Problem 3+8: Raw JSON caching so getFormats() is INSTANT after getVideoInfo()
 * Problem 6: Duration extracted from yt-dlp JSON
 * Problem 7: HLS audio detection via FormatInfo
 */
object MediaExtractor {

    private const val TAG = "MediaExtractor"

    private val semaphore = Semaphore(3)

    // Full result cache (5 min TTL)
    private val cache = ConcurrentHashMap<String, Pair<Long, VideoInfo>>()
    private const val CACHE_TTL_MS = 5 * 60 * 1000L

    // ═══════════════════════════════════════════════════════════════
    // Problem 3+8: RAW JSON CACHE
    // getVideoInfo() stores raw JSON → getFormats() reuses it INSTANTLY
    // ═══════════════════════════════════════════════════════════════
    private val rawJsonCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private const val JSON_CACHE_TTL_MS = 10 * 60 * 1000L

    // HLS URL cache (Bug 1 from original)
    private val hlsUrlCache = ConcurrentHashMap<String, String>()
    private const val HLS_CACHE_TTL_MS = 15 * 60 * 1000L
    private val hlsUrlTimestamps = ConcurrentHashMap<String, Long>()

    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    const val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    // ── Site classification (unchanged from original) ─────────────────

    private val CDN_TOKEN_SITES = setOf(
        "youtube.com", "youtu.be", "youtube-nocookie.com",
        "instagram.com", "instagr.am",
        "tiktok.com", "vm.tiktok.com",
        "twitter.com", "x.com", "t.co",
        "facebook.com", "fb.watch",
        "vimeo.com", "dailymotion.com", "dai.ly", "twitch.tv",
        "reddit.com", "v.redd.it", "bilibili.com", "b23.tv",
        "nicovideo.jp", "streamable.com", "gfycat.com", "redgifs.com", "imgur.com",
        "xhamster.com", "xhamster.desi", "xhamster.one", "xhamster.xxx",
        "pornhub.com", "pornhubpremium.com", "redtube.com", "youporn.com",
        "tube8.com", "beeg.com", "drtuber.com", "tnaflix.com", "nuvid.com",
        "4tube.com", "fux.com", "porn.com", "keezmovies.com", "slutload.com",
        "txxx.com", "youjizz.com", "spankwire.com", "eporner.com", "bravotube.net",
        "porntrex.com", "anysex.com", "porntube.com", "upornia.com", "vjav.com",
        "javhd.com", "motherless.com", "xbabe.com", "hdzog.com", "gotporn.com",
        "sunporno.com", "alphaporno.com", "wetplace.com"
    )

    private val SCRAPE_FIRST_SITES = setOf(
        "xnxx.com", "xnxx.tv", "xvideos.com", "xvideos2.com", "xvideos3.com",
        "spankbang.com", "sexvid.xxx", "sexvid1.com", "sexvid.com", "sexvid.tv",
        "hclips.com", "cliphunter.com", "videosection.com", "extremetube.com",
        "pornoxo.com", "heavyr.com", "yourporn.sexy", "xmoviesforyou.com",
        "ah-me.com", "lubetube.com", "biguz.net"
    )

    // ═══════════════════════════════════════════════════════════════
    // PUBLIC API — ENHANCED
    // ═══════════════════════════════════════════════════════════════

    /**
     * Problem 3+8: Get formats — checks rawJsonCache FIRST for INSTANT response.
     * If getVideoInfo() was called before, this returns in <5ms.
     */
    suspend fun getFormats(url: String, progressListener: ((Double) -> Unit)? = null): ExtractResult {
        val key = cacheKeyOf(url)

        // Check raw JSON cache first — INSTANT if getVideoInfo() was called
        rawJsonCache[key]?.let { (timestamp, json) ->
            if (System.currentTimeMillis() - timestamp < JSON_CACHE_TTL_MS) {
                Log.d(TAG, "⚡ RAW JSON cache hit — INSTANT formats for $key")
                progressListener?.invoke(100.0)
                return ExtractResult.Success(json)
            } else {
                rawJsonCache.remove(key)
            }
        }

        // Cache miss — do full extraction
        return try {
            semaphore.acquire()
            withContext(Dispatchers.IO) {
                // Check if it's a direct media URL — skip yt-dlp entirely
                if (isDirectMediaUrl(url)) {
                    Log.d(TAG, "⚡ Direct media URL detected — skipping yt-dlp")
                    progressListener?.invoke(50.0)
                    val info = buildDirectInfo(url)
                    progressListener?.invoke(100.0)
                    if (info != null) {
                        val json = infoToJson(info)
                        rawJsonCache[key] = System.currentTimeMillis() to json
                        ExtractResult.Success(json)
                    } else {
                        ExtractResult.Error("Could not probe direct URL")
                    }
                } else {
                    val info = extractInternal(url, progressListener)
                    if (info != null) {
                        ExtractResult.Success(infoToJson(info))
                    } else {
                        ExtractResult.Error("Could not extract video from this link.")
                    }
                }
            }
        } finally {
            semaphore.release()
        }
    }

    /**
     * Enhanced getVideoInfo() — caches raw JSON for getFormats() reuse.
     * Problem 3+8: Single yt-dlp call, --no-check-formats
     * Problem 6: Extracts duration field
     */
    suspend fun getVideoInfo(url: String, progressListener: ((Double) -> Unit)? = null): VideoInfo? {
        return try {
            semaphore.acquire()
            withContext(Dispatchers.IO) { extractInternal(url, progressListener) }
        } finally {
            semaphore.release()
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // Problem 3: Direct media URL detection — skips yt-dlp entirely
    // ═══════════════════════════════════════════════════════════════

    fun isDirectMediaUrl(url: String): Boolean {
        val l = url.lowercase()
        val path = l.substringBefore("?").substringBefore("#")
        return path.endsWith(".mp4") || path.endsWith(".mp3") ||
                path.endsWith(".m3u8") || path.endsWith(".webm") ||
                path.endsWith(".mkv") || path.endsWith(".m4a") ||
                path.endsWith(".ogg") || path.endsWith(".opus") ||
                path.endsWith(".flac") || path.endsWith(".wav") ||
                path.endsWith(".ts")
    }

    private fun buildDirectInfo(url: String): VideoInfo? {
        val l = url.lowercase()
        val isHls = l.contains(".m3u8")
        val isAudio = l.endsWith(".mp3") || l.endsWith(".m4a") ||
                l.endsWith(".ogg") || l.endsWith(".opus") ||
                l.endsWith(".flac") || l.endsWith(".wav")

        // Try HEAD request for file size
        val probed = tryDirectProbe(url)

        return VideoInfo(
            streamUrl = url,
            pageUrl = url,
            headers = mapOf("User-Agent" to USER_AGENT),
            useYtDlp = false,
            isHls = isHls,
            fileSize = probed?.first ?: -1L,
            contentType = probed?.second,
            fileType = if (isAudio) "audio" else "video",
            hasAudio = isAudio || isHls || !l.endsWith(".webm") // Most direct URLs have audio
        )
    }

    private fun tryDirectProbe(url: String): Pair<Long, String?>? {
        return try {
            val resp = http.newCall(
                Request.Builder().url(url).head()
                    .header("User-Agent", USER_AGENT)
                    .build()
            ).execute()
            val size = resp.header("Content-Length")?.toLongOrNull() ?: -1L
            val type = resp.header("Content-Type")
            resp.close()
            Pair(size, type)
        } catch (_: Exception) { null }
    }

    // ═══════════════════════════════════════════════════════════════
    // HLS CACHE (unchanged from original)
    // ═══════════════════════════════════════════════════════════════

    fun cacheHlsUrl(pageUrl: String, hlsUrl: String) {
        if (pageUrl.isBlank() || hlsUrl.isBlank()) return
        val key = cacheKeyOf(pageUrl)
        hlsUrlCache[key] = hlsUrl
        hlsUrlTimestamps[key] = System.currentTimeMillis()
        Log.d(TAG, "⚡ Cached HLS: $key → ${hlsUrl.take(80)}…")
    }

    fun getCachedHlsUrl(pageUrl: String): String? {
        val key = cacheKeyOf(pageUrl)
        val url = hlsUrlCache[key] ?: return null
        val timestamp = hlsUrlTimestamps[key] ?: return null
        if (System.currentTimeMillis() - timestamp > HLS_CACHE_TTL_MS) {
            hlsUrlCache.remove(key)
            hlsUrlTimestamps.remove(key)
            return null
        }
        return url
    }

    fun clearHlsCache() {
        hlsUrlCache.clear()
        hlsUrlTimestamps.clear()
    }

    fun clearCache() {
        cache.clear()
        rawJsonCache.clear()
        clearHlsCache()
    }

    // ═══════════════════════════════════════════════════════════════
    // CORE EXTRACTION — Enhanced with JSON caching
    // ═══════════════════════════════════════════════════════════════

    private suspend fun extractInternal(
        raw: String,
        progressListener: ((Double) -> Unit)? = null
    ): VideoInfo? {
        val url = normalizeUrl(raw)
        val host = hostOf(url)
        val key = cacheKeyOf(url)
        Log.d(TAG, "▶ extract host=$host url=$url")

        // Check full result cache
        cache[url]?.let { (timestamp, info) ->
            if (System.currentTimeMillis() - timestamp < CACHE_TTL_MS) {
                Log.d(TAG, "✅ Cache hit: ${info.streamUrl}")
                progressListener?.invoke(100.0)
                return info
            } else {
                cache.remove(url)
            }
        }

        val isCdnToken = CDN_TOKEN_SITES.any { host.contains(it) }
        val isScrape = SCRAPE_FIRST_SITES.any { host.contains(it) }

        progressListener?.invoke(10.0)

        val result = when {
            isCdnToken -> extractCdnToken(url, progressListener)
            isScrape -> extractScrapeFirst(url, host, progressListener)
            else -> extractUnknown(url, host, progressListener)
        }

        progressListener?.invoke(90.0)

        if (result != null) {
            val validated = validateStreamUrl(result)
            if (validated != null) {
                cache[url] = System.currentTimeMillis() to validated
                autoCacheHls(validated)
            }
            return validated
        }

        return null
    }

    // ═══════════════════════════════════════════════════════════════
    // LAYER 1: yt-dlp — Problem 3+8 optimized
    // Single call, --no-check-formats, caches raw JSON
    // ═══════════════════════════════════════════════════════════════

    private fun tryYtDlp(
        url: String,
        progressListener: ((Double) -> Unit)? = null
    ): VideoInfo? {
        return try {
            val req = YoutubeDLRequest(url).apply {
                addOption("--dump-json")
                addOption("--no-playlist")
                addOption("--no-check-formats")     // ← Problem 3: SKIP format validation
                addOption("--no-check-certificate")
                addOption("--geo-bypass")
                addOption("--no-warnings")
                addOption("--no-cache-dir")
                addOption("--socket-timeout", "10")
                addOption("--retries", "1")
                addOption("--user-agent", USER_AGENT)
                addOption("--add-header", "Accept:text/html,application/xhtml+xml,*/*;q=0.8")
                addOption("--add-header", "Referer:$url")
            }
            val out = YoutubeDL.getInstance().execute(req) { pct, _, _ ->
                progressListener?.invoke(pct.toDouble())
            }.out
            if (out.isBlank()) return null

            // Problem 3+8: Cache raw JSON so getFormats() is INSTANT
            val key = cacheKeyOf(url)
            rawJsonCache[key] = System.currentTimeMillis() to out

            val root = JSONObject(out)

            // Problem 6: Extract duration
            val duration = root.optLong("duration", 0L)

            // Parse all formats using FormatInfo for accurate categorization
            val allFormats = FormatInfo.parseAll(root)

            // Find best muxed format (has video + audio)
            val deviceMaxHeight = com.example.nightlibrary.util.DeviceCapabilityUtil.getSafeDownloadHeight()
            val bestMuxed = allFormats
                .filter { it.category == FormatInfo.Category.MUXED && it.height <= deviceMaxHeight }
                .maxByOrNull { it.height * 1000 + it.tbr.toInt() }
                ?: allFormats
                    .filter { it.hasVideo }
                    .maxByOrNull { it.height * 1000 + it.tbr.toInt() }

            val bestUrl = bestMuxed?.url
                ?: root.optString("url", "").ifEmpty { null }
                ?: return null

            if (!bestUrl.startsWith("http")) return null

            val hdrs = mutableMapOf<String, String>()
            root.optJSONObject("http_headers")?.let { h ->
                h.keys().forEach { k -> hdrs[k] = h.optString(k) }
            }

            val fileSize = bestMuxed?.estimatedBytes
                ?: root.optLong("filesize", -1).let {
                    if (it <= 0) root.optLong("filesize_approx", -1) else it
                }

            val info = VideoInfo(
                streamUrl = bestUrl,
                pageUrl = url,
                headers = hdrs,
                isHls = isM3U8(bestUrl),
                fileSize = fileSize,
                duration = duration,
                fileType = bestMuxed?.fileType ?: "video",
                hasAudio = bestMuxed?.hasAudio ?: true,
                formatId = bestMuxed?.formatId
            )

            autoCacheHls(info)
            info
        } catch (e: Exception) {
            Log.w(TAG, "yt-dlp: ${e.message?.take(120)}")
            null
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // parseVideoInfo — used by DownloadFormLink to extract quick info
    // Problem 6: Returns duration
    // Problem 2: Returns accurate hasAudio
    // ═══════════════════════════════════════════════════════════════

    fun parseVideoInfo(json: String): VideoInfo? {
        return try {
            val root = JSONObject(json)
            val allFormats = FormatInfo.parseAll(root)
            val duration = root.optLong("duration", 0L)

            val deviceMaxHeight = com.example.nightlibrary.util.DeviceCapabilityUtil.getSafeDownloadHeight()
            val bestMuxed = allFormats
                .filter { it.category == FormatInfo.Category.MUXED && it.height <= deviceMaxHeight }
                .maxByOrNull { it.height * 1000 + it.tbr.toInt() }
                ?: allFormats.filter { it.hasVideo }.maxByOrNull { it.height * 1000 + it.tbr.toInt() }

            val bestUrl = bestMuxed?.url
                ?: root.optString("url", "").ifEmpty { null }
                ?: return null

            val hdrs = mutableMapOf<String, String>()
            root.optJSONObject("http_headers")?.let { h ->
                h.keys().forEach { k -> hdrs[k] = h.optString(k) }
            }

            VideoInfo(
                streamUrl = bestUrl,
                pageUrl = root.optString("webpage_url", root.optString("original_url", "")),
                headers = hdrs,
                isHls = isM3U8(bestUrl),
                fileSize = bestMuxed?.estimatedBytes ?: -1L,
                duration = duration,
                fileType = bestMuxed?.fileType ?: "video",
                hasAudio = bestMuxed?.hasAudio ?: true,
                formatId = bestMuxed?.formatId
            )
        } catch (e: Exception) {
            Log.e(TAG, "parseVideoInfo error: ${e.message}")
            null
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // ALL STRATEGY/LAYER METHODS — Unchanged from original
    // (extractCdnToken, extractScrapeFirst, extractUnknown,
    //  raceYtDlpAndWebView, raceWebViewAndScrape,
    //  webViewIntercept, fastScrape, siteSpecificScrape,
    //  genericScrape, validateStreamUrl, etc.)
    // ═══════════════════════════════════════════════════════════════

    private suspend fun extractCdnToken(
        url: String, progressListener: ((Double) -> Unit)?
    ): VideoInfo? {
        val result = raceYtDlpAndWebView(url, useYtDlpForDownload = true, progressListener = progressListener)
        if (result != null) return result
        return scrapeFallback(url)
    }

    private suspend fun extractScrapeFirst(
        url: String, host: String, progressListener: ((Double) -> Unit)?
    ): VideoInfo? {
        val fast = withTimeoutOrNull(5_000L) { fastScrape(url, host) }
        if (fast != null) { autoCacheHls(fast); return fast }
        val result = raceYtDlpAndWebView(url, useYtDlpForDownload = false, progressListener = progressListener)
        if (result != null) return result
        return null
    }

    private suspend fun extractUnknown(
        url: String, host: String, progressListener: ((Double) -> Unit)?
    ): VideoInfo? = raceWebViewAndScrape(url, host, progressListener)

    private suspend fun raceYtDlpAndWebView(
        url: String, useYtDlpForDownload: Boolean,
        progressListener: ((Double) -> Unit)? = null
    ): VideoInfo? = coroutineScope {
        val ytDlpDeferred = async(Dispatchers.IO) {
            withTimeoutOrNull(15_000L) {
                tryYtDlp(url, progressListener)?.copy(useYtDlp = useYtDlpForDownload)
            }
        }
        val webViewDeferred = async(Dispatchers.IO) {
            withTimeoutOrNull(20_000L) {
                webViewIntercept(url)?.copy(useYtDlp = useYtDlpForDownload && !isM3U8(url))
            }
        }
        val ytResult = ytDlpDeferred.await()
        if (ytResult != null) {
            webViewDeferred.cancel(); autoCacheHls(ytResult); return@coroutineScope ytResult
        }
        val wvResult = webViewDeferred.await()
        if (wvResult != null) { autoCacheHls(wvResult); return@coroutineScope wvResult }
        null
    }

    private suspend fun raceWebViewAndScrape(
        url: String, host: String, progressListener: ((Double) -> Unit)? = null
    ): VideoInfo? = coroutineScope {
        val webViewDeferred = async(Dispatchers.IO) { withTimeoutOrNull(20_000L) { webViewIntercept(url) } }
        val scrapeDeferred = async(Dispatchers.IO) { withTimeoutOrNull(8_000L) { fastScrape(url, host) } }
        val scrapeResult = scrapeDeferred.await()
        if (scrapeResult != null) { webViewDeferred.cancel(); autoCacheHls(scrapeResult); return@coroutineScope scrapeResult }
        val wvResult = webViewDeferred.await()
        if (wvResult != null) { autoCacheHls(wvResult); return@coroutineScope wvResult }
        null
    }

    private fun fastScrape(url: String, host: String): VideoInfo? {
        val html = fetchHtml(url) ?: return null
        return siteSpecificScrape(html, url, host) ?: genericScrape(html, url)
    }

    private suspend fun scrapeFallback(url: String): VideoInfo? =
        withTimeoutOrNull(8_000L) { fastScrape(url, hostOf(url)) }

    private fun validateStreamUrl(info: VideoInfo): VideoInfo? {
        if (info.useYtDlp) return info
        return try {
            val req = Request.Builder().url(info.streamUrl).head().apply {
                header("User-Agent", USER_AGENT)
                header("Referer", info.pageUrl)
                header("Origin", originOf(info.pageUrl))
                info.headers.forEach { (k, v) -> header(k, v) }
            }.build()
            val resp = http.newCall(req).execute()
            val code = resp.code
            val contentType = resp.header("Content-Type", "")?.lowercase() ?: ""
            val contentLength = resp.header("Content-Length")?.toLongOrNull() ?: -1L
            resp.close()
            when {
                code == 403 || code == 401 -> info
                code !in 200..399 -> null
                contentType.contains("text/html") && !info.isHls -> null
                else -> info.copy(fileSize = contentLength, contentType = contentType)
            }
        } catch (_: Exception) { info }
    }

    // WebView, scraping layers — unchanged from your original
    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun webViewIntercept(pageUrl: String): VideoInfo? {
        val done = CompletableDeferred<VideoInfo?>()
        val handler = Handler(Looper.getMainLooper())
        var wvRef: WebView? = null
        var isCleanedUp = false

        fun cleanup() {
            if (isCleanedUp) return; isCleanedUp = true
            handler.post {
                try { wvRef?.stopLoading(); wvRef?.loadUrl("about:blank"); wvRef?.clearHistory(); wvRef?.removeAllViews(); wvRef?.destroy() } catch (_: Exception) {}
                wvRef = null
            }
        }

        handler.post {
            val ctx = appCtx() ?: run { done.complete(null); return@post }
            try {
                val wv = WebView(ctx); wvRef = wv
                wv.settings.apply {
                    javaScriptEnabled = true; domStorageEnabled = true; loadWithOverviewMode = true
                    useWideViewPort = true; mediaPlaybackRequiresUserGesture = false
                    userAgentString = USER_AGENT; cacheMode = WebSettings.LOAD_NO_CACHE
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    blockNetworkImage = true; loadsImagesAutomatically = false
                }
                handler.postDelayed({ if (!done.isCompleted) { done.complete(null); cleanup() } }, 18_000L)
                wv.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(v: WebView?, r: WebResourceRequest?): WebResourceResponse? {
                        val u = r?.url?.toString() ?: return null
                        if (!done.isCompleted && looksLikeVideoStream(u)) {
                            val h = buildMap {
                                r.requestHeaders?.forEach { (k, v2) -> put(k, v2) }
                                putIfAbsent("User-Agent", USER_AGENT)
                                putIfAbsent("Referer", pageUrl)
                                putIfAbsent("Origin", originOf(pageUrl))
                                val cookies = try { CookieManager.getInstance().getCookie(pageUrl) } catch (_: Exception) { null }
                                if (!cookies.isNullOrBlank()) putIfAbsent("Cookie", cookies)
                            }
                            val info = VideoInfo(u, pageUrl, h, isHls = isM3U8(u))
                            autoCacheHls(info); done.complete(info)
                            handler.postDelayed({ cleanup() }, 500)
                        }
                        return null
                    }
                    override fun onReceivedError(v: WebView?, c: Int, d: String?, u: String?) {
                        if (u == pageUrl && !done.isCompleted) { done.complete(null); cleanup() }
                    }
                }
                wv.loadUrl(pageUrl)
            } catch (e: Exception) { cleanup(); if (!done.isCompleted) done.complete(null) }
        }
        return try { done.await() } finally { cleanup() }
    }

    private fun looksLikeVideoStream(u: String): Boolean {
        val l = u.lowercase()
        if (l.endsWith(".js") || l.endsWith(".css") || l.endsWith(".png") || l.endsWith(".jpg") ||
            l.endsWith(".gif") || l.endsWith(".svg") || l.endsWith(".woff") || l.endsWith(".woff2") ||
            l.endsWith(".ttf") || l.contains("analytics") || l.contains("tracking") ||
            l.contains("googlesyndication") || l.contains("doubleclick") ||
            l.contains("adserver") || l.contains("facebook.com/tr")
        ) return false
        return isM3U8(u) || (l.contains(".mp4") && !l.contains(".mp4.js")) || l.contains(".webm") ||
                l.contains("videoplayback") || l.contains("/hls/") || l.contains("get_file") ||
                (l.contains("/cdn") && l.contains("mp4")) || (l.contains("video") && l.contains("cdn"))
    }

    private fun siteSpecificScrape(html: String, pageUrl: String, host: String): VideoInfo? {
        val url = when {
            host.contains("xnxx") || host.contains("xvideos") ->
                Regex("""setVideoUrl(?:High|Low|MP4)\s*\(\s*['"](\bhttps?://[^'"]+)['"]""").find(html)?.groupValues?.get(1)
                    ?: Regex("""html5player\.setVideoUrl\s*\(\s*['"](\bhttps?://[^'"]+)['"]""").find(html)?.groupValues?.get(1)
                    ?: Regex(""""videoUrl"\s*:\s*"(\bhttps?://[^"]+)"""").find(html)?.groupValues?.get(1)
            host.contains("sexvid") -> sexVidExtract(html)
            host.contains("spankbang") ->
                Regex("""(?:m3u8|1080p|720p|480p|320p|240p)\s*:\s*['"](\bhttps?://[^'"]+)['"]""").find(html)?.groupValues?.get(1)
                    ?: Regex("""['"](\bhttps?://[^'"]+\.m3u8[^'"]*)['"]""").find(html)?.groupValues?.get(1)
            host.contains("hclips") ->
                Regex("""file\s*:\s*['"](\bhttps?://[^'"]+\.mp4[^'"]*)['"]""").find(html)?.groupValues?.get(1)
            host.contains("cliphunter") ->
                Regex(""""file"\s*:\s*"(\bhttps?://[^"]+\.mp4[^"]*)"[^}]*"label"""").find(html)?.groupValues?.get(1)
            host.contains("videosection") || host.contains("ah-me") || host.contains("lubetube") ->
                Regex("""<source[^>]+src=['"](\bhttps?://[^'"]+\.mp4[^'"]*)['"]""").find(html)?.groupValues?.get(1)
            host.contains("yourporn") || host.contains("heavyr") ->
                Regex(""""(?:contentUrl|videoUrl|embedUrl)"\s*:\s*"(\bhttps?://[^"]+)"""").find(html)?.groupValues?.get(1)?.replace("\\/", "/")
            else -> null
        }
        val clean = url?.replace("\\/", "/")?.trim() ?: return null
        if (!clean.startsWith("http")) return null
        val info = VideoInfo(resolveUrl(clean, pageUrl), pageUrl, mapOf("Referer" to pageUrl, "Origin" to originOf(pageUrl)), isHls = isM3U8(clean))
        autoCacheHls(info); return info
    }

    private fun sexVidExtract(html: String): String? {
        val pats = listOf(
            Regex("""(?:video_url|videoUrl|file|src|url)\s*[=:]\s*['"](\bhttps?://[^'"]+\.mp4[^'"]*)['"]"""),
            Regex("""['"]file['"]\s*:\s*['"](\bhttps?://[^'"]+)['"]"""),
            Regex("""['"](\bhttps?://[^'"]*get_file[^'"]+\.mp4[^'"]*)['"]"""),
            Regex("""['"](\bhttps?://[^'"]+\.mp4(?:[?#][^'"]*)?)['"]""")
        )
        for (p in pats) { val m = p.find(html)?.groupValues?.get(1)?.replace("\\/", "/"); if (!m.isNullOrBlank() && m.startsWith("http")) return m }
        return null
    }

    private fun genericScrape(html: String, pageUrl: String): VideoInfo? {
        val m3u8 = Regex("""['"](\bhttps?://[^'"]+\.m3u8[^'"]*)['"]""").find(html)?.groupValues?.get(1)?.replace("\\/", "/")
        if (!m3u8.isNullOrBlank()) {
            val info = VideoInfo(resolveUrl(m3u8, pageUrl), pageUrl, mapOf("Referer" to pageUrl), isHls = true)
            autoCacheHls(info); return info
        }
        val mp4 = Regex("""['"](\bhttps?://[^'"]+\.mp4(?:[?#][^'"]*)?)['"]""").find(html)?.groupValues?.get(1)?.replace("\\/", "/")
        if (!mp4.isNullOrBlank()) return VideoInfo(resolveUrl(mp4, pageUrl), pageUrl, mapOf("Referer" to pageUrl))
        val src = Regex("""<(?:video|source)[^>]+src=['"](\bhttps?://[^'"]+)['"]""").find(html)?.groupValues?.get(1)
        if (!src.isNullOrBlank()) { val info = VideoInfo(src, pageUrl, mapOf("Referer" to pageUrl), isHls = isM3U8(src)); autoCacheHls(info); return info }
        return null
    }

    // ═══════════════════════════════════════════════════════════════
    // HELPERS — unchanged
    // ═══════════════════════════════════════════════════════════════

    private fun autoCacheHls(info: VideoInfo) {
        if (info.isHls && info.streamUrl.isNotBlank() && info.pageUrl.isNotBlank()) {
            cacheHlsUrl(info.pageUrl, info.streamUrl)
        }
    }

    private fun cacheKeyOf(url: String): String =
        normalizeUrl(url).substringBefore("?").substringBefore("#").trimEnd('/').lowercase()

    private fun fetchHtml(url: String): String? = try {
        http.newCall(Request.Builder().url(url).header("User-Agent", USER_AGENT)
            .header("Accept", "text/html,*/*;q=0.8").header("Accept-Language", "en-US,en;q=0.5")
            .header("Referer", url).build()).execute().use { if (it.isSuccessful) it.body?.string() else null }
    } catch (_: Exception) { null }

    fun isM3U8(url: String): Boolean { val l = url.lowercase(); return l.contains(".m3u8") || (l.contains("m3u8") && l.contains("playlist")) }
    private fun hostOf(url: String) = try { android.net.Uri.parse(url).host?.lowercase() ?: "" } catch (_: Exception) { "" }
    private fun originOf(url: String) = try { val u = android.net.Uri.parse(url); "${u.scheme}://${u.host}" } catch (_: Exception) { url }
    private fun resolveUrl(path: String, base: String) = when {
        path.startsWith("http") -> path; path.startsWith("//") -> "https:$path"
        path.startsWith("/") -> { val u = android.net.Uri.parse(base); "${u.scheme}://${u.host}$path" }
        else -> { val slash = base.lastIndexOf('/'); if (slash >= 0) base.substring(0, slash + 1) + path else path }
    }
    private fun normalizeUrl(url: String): String { val l = url.lowercase(); return when {
        l.contains("xhamster") && !l.contains("xhamster.com") -> url.replace(Regex("xhamster[0-9]*\\.[a-z]{2,6}"), "xhamster.com")
        l.contains("xnxx") && !l.contains("xnxx.com") -> url.replace(Regex("xnxx[0-9]*\\.[a-z]{2,6}"), "xnxx.com")
        else -> url
    }}
    private fun appCtx(): Context? = try { YoutubeDL.getInstance().javaClass.getDeclaredField("appContext").also { it.isAccessible = true }.get(YoutubeDL.getInstance()) as? Context } catch (_: Exception) { null }

    private fun infoToJson(i: VideoInfo): String = JSONObject().apply {
        put("url", i.streamUrl); put("pageUrl", i.pageUrl); put("useYtDlp", i.useYtDlp)
        put("isHls", i.isHls); put("duration", i.duration)
        i.formatId?.let { put("formatId", it) }
        if (i.fileSize > 0) put("filesize", i.fileSize)
        if (i.headers.isNotEmpty()) put("http_headers", JSONObject(i.headers))
        put("title", "Secured Media"); put("extractor_key", "nightlibrary_hybrid")
        put("vcodec", "h264"); put("acodec", if (i.hasAudio) "aac" else "none")
        put("formats", JSONArray().apply {
            put(JSONObject().apply {
                put("url", i.streamUrl); put("format_note", if (i.isHls) "HLS Stream" else "Direct Stream")
                put("ext", "mp4"); put("vcodec", "h264"); put("acodec", if (i.hasAudio) "aac" else "none")
                put("protocol", if (i.isHls) "m3u8" else "https")
                if (i.fileSize > 0) put("filesize", i.fileSize)
                if (i.duration > 0) put("duration", i.duration)
            })
        })
    }.toString()
}